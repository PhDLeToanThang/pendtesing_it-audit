<!--docutune:disable -->

> [!NOTE]
>
> Microsoft Defender for Cloud Apps is now part of [Microsoft Defender XDR](https://security.microsoft.com), which correlates signals from across the Microsoft Defender suite and provides incident-level detection, investigation, and powerful response capabilities. For more information, see [Microsoft Defender for Cloud Apps in Microsoft Defender XDR](/microsoft-365/security/defender/microsoft-365-security-center-defender-cloud-apps).

<!--docutune:enable -->
