---
title: include file
description: include file
ms.collection: M365-security-compliance
ms.service: defender-for-cloud-apps
author: batamig
ms.topic: include
ms.date: 06/18/2023
ms.author: bagol
ms.custom: include file
---

Use this app connector to access SaaS Security Posture Management (SSPM) features, via security controls reflected in Microsoft Secure Score. [Learn more](/microsoft-365/security/defender/microsoft-secure-score).