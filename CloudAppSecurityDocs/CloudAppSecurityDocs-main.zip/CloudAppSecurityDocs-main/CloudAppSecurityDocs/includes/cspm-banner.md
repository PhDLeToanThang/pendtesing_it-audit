<!--docutune:disable -->

> [!NOTE]
>
> Cloud Security Posture Management (CSPM) is now supported in [Microsoft Defender for Cloud](/azure/defender-for-cloud/). Once [Microsoft Defender for Cloud Apps fully converges with the Microsoft Defender Portal](/microsoft-365/security/defender/microsoft-365-security-center-defender-cloud-apps), CSPM will only be available in the new Microsoft Defender for Cloud page.

<!--docutune:enable -->
