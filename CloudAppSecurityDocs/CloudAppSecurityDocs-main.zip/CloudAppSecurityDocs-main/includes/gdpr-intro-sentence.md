---
title: include file
description: include file
services: active-directory
author: eross-msft
 
ms.service: active-directory
ms.topic: include
ms.date: 04/24/2018
ms.author: lizross
ms.custom: include file
---

>[!Note] 
> This article provides steps for how to delete personal data from the device or service and can be used to support your obligations under the GDPR. If you’re looking for general info about GDPR, see the [GDPR section of the Service Trust portal](https://servicetrust.microsoft.com/ViewPage/GDPRGetStarted).
