# THIS REPOSITORY IS CLOSED

This content has moved to [defender-docs-pr/CloudAppSecurityDocs](https://github.com/MicrosoftDocs/defender-docs-pr/tree/main/CloudAppSecurityDocs).